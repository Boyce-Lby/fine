<?php

return array(

    'DR_UPDATE'		=> '2017.7.24',
    'DR_VERSION'	=> '1.0.1',
);

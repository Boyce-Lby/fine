<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * FineCMS
 */

/**
 * 模型域名归类文件
 */

return array(


);
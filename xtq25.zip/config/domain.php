<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * FineCMS
 */

/**
 * 站点域名文件
 */

return array(

	'qjsm.zuoyounet.cn'             => 1,

);
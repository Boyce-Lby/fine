<?php



if (!defined('BASEPATH')) exit('No direct script access allowed');



$active_group	= 'default';

$query_builder	= TRUE;



$db['default']	= array(

	'dsn'		=> '',

	'hostname'	=> 'qdm16287321.my3w.com',

	'username'	=> 'qdm16287321',

	'password'	=> 'qdm16287321xyz',

	'port'		=> '3306',

	'database'	=> 'qdm16287321_db',

	'dbdriver'	=> 'mysqli',

	'dbprefix'	=> 'xtq_',

	'pconnect'	=> FALSE,

	'db_debug'	=> true,

	'cache_on'	=> FALSE,

	'cachedir'	=> 'cache/sql/',

	'char_set'	=> 'utf8',

	'dbcollat'	=> 'utf8_general_ci',

	'swap_pre'	=> '',

	'autoinit'	=> FALSE,

	'encrypt'	=> FALSE,

	'compress'	=> FALSE,

	'stricton'	=> FALSE,

	'failover'	=> array(),

);


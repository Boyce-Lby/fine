<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * FineCMS
 */

/**
 * 系统配置文件
 */

return array (
    'SYS_LOG' => 1,
    'SYS_KEY' => 'CI3B31317B763541',
    'SYS_DEBUG' => 0,
    'SYS_EMAIL' => '',
    'SYS_AUTO_CACHE' => 0,
    'SITE_ADMIN_CODE' => 0,
    'SITE_ADMIN_PAGESIZE' => '12',
    'SYS_CACHE_INDEX' => 1110,
    'SYS_CACHE_MSHOW' => 1110,
    'SYS_CACHE_MSEARCH' => 1110,
    'SYS_CACHE_LIST' => 1110,
    'SYS_CACHE_MEMBER' => 1110,
    'SYS_CACHE_ATTACH' => 1110,
    'SYS_CACHE_FORM' => 1110,
    'SYS_CACHE_TAG' => 1110,
    'SYS_CAT_MODULE' => 0,
);
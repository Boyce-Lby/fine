<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-25 10:14:22 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 11:28:39 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 12:11:38 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 12:14:06 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 12:14:51 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 12:16:08 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 12:16:55 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 12:17:02 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 12:17:08 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 12:18:34 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 12:59:56 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 13:01:49 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 13:20:12 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 13:37:10 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 13:45:29 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 14:03:56 --> Severity: Parsing Error --> syntax error, unexpected end of file /data/home/qxu1608110336/htdocs/cache/templates/templates.pc.xtq.common.index.html.cache.php 478
ERROR - 2017-07-25 14:04:20 --> Severity: Parsing Error --> syntax error, unexpected end of file /data/home/qxu1608110336/htdocs/cache/templates/templates.pc.xtq.common.index.html.cache.php 478
ERROR - 2017-07-25 14:04:21 --> Severity: Parsing Error --> syntax error, unexpected end of file /data/home/qxu1608110336/htdocs/cache/templates/templates.pc.xtq.common.index.html.cache.php 478
ERROR - 2017-07-25 14:04:21 --> Severity: Parsing Error --> syntax error, unexpected end of file /data/home/qxu1608110336/htdocs/cache/templates/templates.pc.xtq.common.index.html.cache.php 478
ERROR - 2017-07-25 14:04:22 --> Severity: Parsing Error --> syntax error, unexpected end of file /data/home/qxu1608110336/htdocs/cache/templates/templates.pc.xtq.common.index.html.cache.php 478
ERROR - 2017-07-25 14:04:22 --> Severity: Parsing Error --> syntax error, unexpected end of file /data/home/qxu1608110336/htdocs/cache/templates/templates.pc.xtq.common.index.html.cache.php 478
ERROR - 2017-07-25 14:34:52 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 14:39:52 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 14:40:28 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 14:46:37 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 14:57:08 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 14:58:26 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 14:59:02 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 15:40:53 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 15:45:24 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 15:46:32 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 15:46:40 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 15:46:46 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 15:47:30 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 15:47:56 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2017-07-25 15:48:59 --> Cache: Failed to create Memcache(d) object; extension not loaded?

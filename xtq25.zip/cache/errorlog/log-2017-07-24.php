<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-24 19:24:11 --> Unable to connect to the database
ERROR - 2017-07-24 19:31:37 --> Cache: Failed to create Memcache(d) object; extension not loaded?

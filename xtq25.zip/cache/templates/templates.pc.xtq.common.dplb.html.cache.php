<?php if ($fn_include = $this->_include("header.html")) include($fn_include); ?>
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/css/flexslider.css" />
<link href="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.css" rel="stylesheet" />

<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/css/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="<?php echo THEME_PATH; ?>xtq/css/mixitup.css">

<!--面包屑导航开始-->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-4">
                <h1>店铺列表</h1>
            </div>
            <div class="col-lg-8 col-sm-8">
                <ol class="breadcrumb pull-right">
                    <li><a href="index.html">首页</a></li>
                    <li class="active"><?php echo dr_catpos($catid, '', true, '<a href="[url]">[name]</a>'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!--面包屑导航结束-->
<div class="my_con">
    <!--筛选  -->
    <!-- <div class="container">

        <div class="row">
            <div class="col-md-6">
                <ul id="filters" class="clearfix">
                    <li><span class="filter active">分类</span></li>
                    <li><span class="filter">分类1</span></li>
                </ul>
            </div>
        </div>
    </div> -->
    <!--列表  -->
    <div class="container">
        <div class="row">

            <!--左边列表  -->
            <div class="col-md-6">
                <?php $rt = $this->list_tag("action=module catid=$catid order=displayorder,updatetime page=1"); if ($rt) extract($rt); $count=count($return); if (is_array($return)) { foreach ($return as $key=>$t) { ?>
                <div class="blog-left wow fadeInLeft">
                    <div class="blog-img">
                        <a href="<?php echo $t['url']; ?>"><img src="<?php echo dr_get_file($t['thumb']); ?>" alt="" /></a>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="blog-two-info">
                                <p>
                                    <i class="fa fa-user"></i> 店主：<?php echo $t['title']; ?> |
                                    <i class="fa fa-calendar"></i> 成立时间：<?php echo dr_date($t['kdsj'], 'Y-m-d'); ?> |
                                    <i class="fa fa-share"></i> 访问量：<?php echo $t['fangwenliang']; ?>
                                    <br> <?php if ($t['keywords']) {  $tag = explode(',',$t['keywords']);?>
                                    <i class="fa fa-tags"></i> 标签 : <?php if (is_array($tag)) { $count=count($tag);foreach ($tag as $c) { ?><a href="<?php echo dr_tags_url($c); ?>"><span class="label label-info"><?php echo $c; ?></span></a><?php } } ?>
                                    </span>
                                    <?php } ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="blog-content">
                        <h3>
                            <a href="<?php echo $t['url']; ?>"><?php echo $t['title']; ?></a>
                        </h3>
                        <p>
                            <?php echo $t['description']; ?>
                        </p>
                    </div>
                    <a href="<?php echo $t['url']; ?>" class="btn btn-primary">进店铺</a>

                </div>
                <?php } } ?>
                <div class="blog-left wow fadeInLeft">
                    <div class="blog-img">
                        <a href="njxd.html"><img src="<?php echo THEME_PATH; ?>xtq/img/blog/img8.jpg" alt="" /></a>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="blog-two-info">
                                <p>
                                    <i class="fa fa-user"></i> 店主：我问问 |
                                    <i class="fa fa-calendar"></i> 成立时间：2017.07.07 |
                                    <i class="fa fa-share"></i> 访问量：1000
                                    <br>
                                    <i class="fa fa-tags"></i> 标签 :
                                    <a href="#"><span class="label label-info">食品</span></a>
                                    <a href="#"><span class="label label-info">绿色</span></a>
                                    <a href="#"><span class="label label-info">养生</span></a>
                                    <a href="#"><span class="label label-info">农产品</span></a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="blog-content">
                        <h3>
                            <a href="njxd.html">农家小店</a>
                        </h3>
                        <p>
                            店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容
                        </p>
                    </div>
                    <a href="njxd.html" class="btn btn-primary">进店铺</a>

                </div>
            </div>
            <!--右边列表  -->
            <div class="col-md-6">
                <div class="blog-right wow fadeInRight">
                    <div class="blog-img">
                        <a href="njxd.html"><img src="<?php echo THEME_PATH; ?>xtq/img/blog/img8.jpg" alt="" /></a>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="blog-two-info">
                                <p>
                                    <i class="fa fa-user"></i> 店主：我问问 |
                                    <i class="fa fa-calendar"></i> 成立时间：2017.07.07 |
                                    <i class="fa fa-share"></i> 访问量：1000
                                    <br>
                                    <i class="fa fa-tags"></i> 标签 :
                                    <a href="#"><span class="label label-info">食品</span></a>
                                    <a href="#"><span class="label label-info">绿色</span></a>
                                    <a href="#"><span class="label label-info">养生</span></a>
                                    <a href="#"><span class="label label-info">农产品</span></a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="blog-content">
                        <h3>
                            <a href="njxd.html">农家小店</a>
                        </h3>
                        <p>
                            店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容
                        </p>
                    </div>
                    <a href="njxd.html" class="btn btn-primary">进店铺</a>

                </div>
                <div class="blog-right wow fadeInRight">
                    <div class="blog-img">
                        <a href="njxd.html"><img src="<?php echo THEME_PATH; ?>xtq/img/blog/img8.jpg" alt="" /></a>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="blog-two-info">
                                <p>
                                    <i class="fa fa-user"></i> 店主：我问问 |
                                    <i class="fa fa-calendar"></i> 成立时间：2017.07.07 |
                                    <i class="fa fa-share"></i> 访问量：1000
                                    <br>
                                    <i class="fa fa-tags"></i> 标签 :
                                    <a href="#"><span class="label label-info">食品</span></a>
                                    <a href="#"><span class="label label-info">绿色</span></a>
                                    <a href="#"><span class="label label-info">养生</span></a>
                                    <a href="#"><span class="label label-info">农产品</span></a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="blog-content">
                        <h3>
                            <a href="njxd.html">农家小店</a>
                        </h3>
                        <p>
                            店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容店铺介绍内容
                        </p>
                    </div>
                    <a href="njxd.html" class="btn btn-primary">进店铺</a>

                </div>

            </div>





            <!--blog end-->
        </div>

    </div>

</div>
<?php if ($fn_include = $this->_include("footer.html")) include($fn_include); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/hover-dropdown.js"></script>
<script defer src="<?php echo THEME_PATH; ?>xtq/js/jquery.flexslider.js"></script>
<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.js"></script>

<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/jquery.parallax-1.1.3.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.carousel.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/mixitup.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/jquery.easing.min.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/link-hover.js"></script>


<script src="<?php echo THEME_PATH; ?>xtq/js/jquery.magnific-popup.js"></script>
<script>
    new WOW().init();
</script>

</body>

</html>
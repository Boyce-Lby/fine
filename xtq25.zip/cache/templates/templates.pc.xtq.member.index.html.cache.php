<?php if ($fn_include = $this->_include("../common/header.html")) include($fn_include); ?>
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/css/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="<?php echo THEME_PATH; ?>xtq/css/mixitup.css">
<link href="<?php echo THEME_PATH; ?>xtq/css/cropper.min.css" rel="stylesheet">
<link href="<?php echo THEME_PATH; ?>xtq/css/sitelogo.css" rel="stylesheet">

<!--面包屑导航开始-->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-4">
                <h1>个人中心</h1>
            </div>
            <div class="col-lg-8 col-sm-8">
                <ol class="breadcrumb pull-right">
                    <li><a href="/">首页</a></li>
                    <li class="active">个人中心</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!--面包屑导航结束-->
<div class="my_con">
    <div class="login-bg profile-container">
        <br>
        <div class="container" style="padding-bottom:100px;">
            <div class="profile-header row">
                <div class="col-lg-2 col-md-4 col-sm-12 text-center">
                    <img src="<?php echo $member['avatar_url']; ?>" data-toggle="modal" data-target="#avatar-modal" class="header-avatar">
                </div>
                <div class="col-lg-5 col-md-8 col-sm-12 profile-info">
                    <div class="header-fullname"><?php echo $member['name']; ?></div>
                    <button class="btn btn-success btn-sm  btn-follow" data-toggle="modal" data-target="#editUserModal" data-uid="<?php echo $member['username']; ?>">
                            <i class="fa fa-edit"></i> 编辑个人信息
                        </button>
                    <div class="header-information">
                        <?php echo $member['jianjie']; ?>
                    </div>
                    <div class="header-information">
                        <span>手机：<?php echo $member['username']; ?></span> | <span>邮箱： <?php echo $member['email']; ?></span> | <span>用户组：普通用户</span>
                    </div>
                </div>
                <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12 profile-stats">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 stats-col">
                            <div class="stats-value pink">￥284</div>
                            <div class="stats-title">零钱</div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 stats-col">
                            <div class="stats-value pink">￥803</div>
                            <div class="stats-title">FOLLOWERS</div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 stats-col">
                            <div class="stats-value pink">1207</div>
                            <div class="stats-title">POSTS</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 inlinestats-col">
                            <i class="glyphicon glyphicon-map-marker"></i> 地址
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 inlinestats-col">
                            钱包: <strong>￥250</strong>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 inlinestats-col">
                            年龄: <strong>24</strong>
                        </div>
                    </div>
                </div>
            </div>
            <div class="profile-body">
                <div class="col-lg-12">
                    <div class="tabbable">
                        <ul class="nav nav-tabs tabs-flat  nav-justified" id="myTab11">
                            <li class="active">
                                <a data-toggle="tab" href="#overview">
                                                        订单列表
                                                    </a>
                            </li>
                            <li class="tab-red">
                                <a data-toggle="tab" href="#news">
                                                        已发布信息
                                                    </a>
                            </li>
                            <li class="tab-red">
                                <a data-toggle="tab" href="#timeline">
                                                        实名认证
                                                    </a>
                            </li>
                            <li class="tab-palegreen">
                                <a data-toggle="tab" id="contacttab" href="#contacts">
                                                        手机邮箱绑定
                                                    </a>
                            </li>
                            <li class="tab-yellow">
                                <a data-toggle="tab" href="#settings">
                                                        修改密码
                                                    </a>
                            </li>
                        </ul>
                        <div class="tab-content tabs-flat">
                            <div id="overview" class="tab-pane pad-all-15 active">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <section class="panel">
                                            <table class="table table-responsive table-striped table-advance table-hover order-table">
                                                <thead>
                                                    <tr>
                                                        <th>编号</th>
                                                        <th>商品信息</th>
                                                        <th>订单金额</th>
                                                        <th>订单状态</th>
                                                        <th>操作</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <a href="#">1</a>
                                                        </td>
                                                        <td>
                                                            <a href="#">
                                                                <img src="<?php echo THEME_PATH; ?>xtq/img/product2.jpg" alt="商品名字" width="40" height="40"> 商品名字商品名字
                                                            </a>
                                                        </td>
                                                        <td>￥111 </td>
                                                        <td><span class="label label-info label-mini">已取消</span></td>
                                                        <td>
                                                            <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                                                            <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                                                            <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <a href="#">2</a>
                                                        </td>
                                                        <td>
                                                            <a href="#">
                                                                <img src="<?php echo THEME_PATH; ?>xtq/img/product2.jpg" alt="商品名字" width="40" height="40"> 商品名字商品名字
                                                            </a>
                                                        </td>
                                                        <td>￥111 </td>
                                                        <td><span class="label label-warning label-mini">进行中</span></td>
                                                        <td>
                                                            <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                                                            <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                                                            <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <a href="#">3</a>
                                                        </td>
                                                        <td>
                                                            <a href="#">
                                                                <img src="<?php echo THEME_PATH; ?>xtq/img/product2.jpg" alt="商品名字" width="40" height="40"> 商品名字商品名字
                                                            </a>
                                                        </td>
                                                        <td>￥111 </td>
                                                        <td><span class="label label-success label-mini">完成</span></td>
                                                        <td>
                                                            <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                                                            <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                                                            <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <a href="#">4</a>
                                                        </td>
                                                        <td>
                                                            <a href="#">
                                                                <img src="<?php echo THEME_PATH; ?>xtq/img/product2.jpg" alt="商品名字" width="40" height="40"> 商品名字商品名字
                                                            </a>
                                                        </td>
                                                        <td>￥111 </td>
                                                        <td><span class="label label-danger label-mini">关闭</span></td>
                                                        <td>
                                                            <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                                                            <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                                                            <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="5">
                                                            <ul class="pagination">
                                                                <li class="disabled"><a href="#" aria-label="Previous"><span aria-hidden="true">«</span></a></li>
                                                                <li class="active"><a href="#">1</a></li>
                                                                <li><a href="#">2</a></li>
                                                                <li><a href="#">3</a></li>
                                                                <li><a href="#">4</a></li>
                                                                <li><a href="#">5</a></li>
                                                                <li><a href="#" aria-label="Next"><span aria-hidden="true">»</span></a></li>
                                                            </ul>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </section>
                                    </div>
                                </div>
                            </div>
                            <div id="news" class="tab-pane pad-all-15">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <table class="table table-responsive table-striped table-advance table-hover order-table">
                                            <thead>
                                                <tr>
                                                    <th>编号</th>
                                                    <th>文章标题</th>
                                                    <th>作者</th>
                                                    <th>状态</th>
                                                    <th>操作</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <a href="#">1</a>
                                                    </td>
                                                    <td>
                                                        <a href="#">
                                                                   		 文章标题文章标题
                                                                </a>
                                                    </td>
                                                    <td>admin</td>
                                                    <td><span class="label label-info label-mini">正常</span></td>
                                                    <td>
                                                        <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                                                        <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                                                        <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href="#">1</a>
                                                    </td>
                                                    <td>
                                                        <a href="#">
                                                                   		 文章标题文章标题
                                                                </a>
                                                    </td>
                                                    <td>admin</td>
                                                    <td><span class="label label-info label-mini">正常</span></td>
                                                    <td>
                                                        <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                                                        <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                                                        <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href="#">1</a>
                                                    </td>
                                                    <td>
                                                        <a href="#">
                                                                   		 文章标题文章标题
                                                                </a>
                                                    </td>
                                                    <td>admin</td>
                                                    <td><span class="label label-info label-mini">正常</span></td>
                                                    <td>
                                                        <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                                                        <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                                                        <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <ul class="pagination">
                                                            <li class="disabled"><a href="#" aria-label="Previous"><span aria-hidden="true">«</span></a></li>
                                                            <li class="active"><a href="#">1</a></li>
                                                            <li><a href="#">2</a></li>
                                                            <li><a href="#">3</a></li>
                                                            <li><a href="#">4</a></li>
                                                            <li><a href="#">5</a></li>
                                                            <li><a href="#" aria-label="Next"><span aria-hidden="true">»</span></a></li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div id="timeline" class="tab-pane pad-all-15">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <form id="shimin" action="" method="post">
                                            <div class="form-group">
                                                <label for="name">姓名</label>
                                                <input type="text" class="form-control" id="name" name="name" placeholder="请输入姓名" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="idCard">身份证号码</label>
                                                <input type="text" class="form-control" id="idCard" name="idCard" placeholder="请输入身份证号码" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputFile">身份证正面照</label>
                                                <input type="file" id="exampleInputFile" required>
                                                <p class="help-block">图片大小不能超过2M，图片清晰，文字可辨.</p>
                                            </div>
                                            <button type="submit" class="btn btn-default">提交</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div id="contacts" class="tab-pane pad-all-15">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <form id="mobile-bd" action="" method="post">
                                            <div class="form-group">
                                                <label for="mobile">手机号</label>
                                                <input type="text" class="form-control" id="mobile" name="mobile" placeholder="请输入手机号" required>
                                            </div>
                                            <button type="submit" class="btn btn-default">绑定</button>
                                        </form>
                                        <form id="email-bd" action="" method="post">
                                            <div class="form-group">
                                                <label for="email">邮箱</label>
                                                <input type="text" class="form-control" id="email" name="email" placeholder="请输入邮箱" required>
                                            </div>
                                            <button type="submit" class="btn btn-default">绑定</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div id="settings" class="tab-pane pad-all-15">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <form id="password-edit" action="" method="post">
                                            <div class="form-group">
                                                <label for="oldPassword">原密码</label>
                                                <input type="text" class="form-control" id="oldPassword" name="oldPassword" placeholder="请输入原密码" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="newPassword">新密码</label>
                                                <input type="text" class="form-control" id="newPassword" name="newPassword" placeholder="请输入新密码" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="reNewPassword">确认新密码</label>
                                                <input type="text" class="form-control" id="reNewPassword" name="reNewPassword" placeholder="请确认新密码" required>
                                            </div>
                                            <button type="submit" class="btn btn-default">确定</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--用户信息编辑 model  -->
    <div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="editUserModalLabel">修改用户信息</h4>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="recipient-name" class="control-label">昵称:</label>
                            <input type="text" class="form-control" id="recipient-name">
                        </div>
                        <div class="form-group">
                            <label for="recipient-age" class="control-label">年龄:</label>
                            <input type="text" class="form-control" id="recipient-age">
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="control-label">个人说明:</label>
                            <textarea class="form-control" id="message-text"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="address-text" class="control-label">地址:</label>
                            <input type="text" class="form-control" id="address-text">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                    <button type="button" class="btn btn-primary">保存</button>
                </div>
            </div>
        </div>
    </div>
    <!--用户信息编辑model  end-->
    <!--头像上传model  -->
    <div class="modal fade" id="avatar-modal" aria-hidden="true" aria-labelledby="avatar-modal-label" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <!--<form class="avatar-form" action="upload-logo.php" enctype="multipart/form-data" method="post">-->
                <form class="avatar-form">
                    <div class="modal-header">
                        <button class="close" data-dismiss="modal" type="button">&times;</button>
                        <h4 class="modal-title" id="avatar-modal-label">上传图片</h4>
                    </div>
                    <div class="modal-body">
                        <div class="avatar-body">
                            <div class="avatar-upload">
                                <input class="avatar-src" name="avatar_src" type="hidden">
                                <input class="avatar-data" name="avatar_data" type="hidden">
                                <label for="avatarInput" style="line-height: 35px;">图片上传</label>
                                <button class="btn btn-danger" type="button" style="height: 35px;" onclick="$('input[id=avatarInput]').click();">请选择图片</button>
                                <span id="avatar-name"></span>
                                <input class="avatar-input hide" id="avatarInput" name="avatar_file" type="file"></div>
                            <div class="row">
                                <div class="col-md-9">
                                    <div class="avatar-wrapper"></div>
                                </div>
                                <div class="col-md-3">
                                    <div class="avatar-preview preview-lg" id="imageHead"></div>
                                    <!--<div class="avatar-preview preview-md"></div>
								<div class="avatar-preview preview-sm"></div>-->
                                </div>
                            </div>
                            <div class="row avatar-btns">
                                <div class="col-md-4">
                                    <div class="btn-group">
                                        <button class="btn btn-danger fa fa-undo" data-method="rotate" data-option="-90" type="button" title="Rotate -90 degrees"> 向左旋转</button>
                                    </div>
                                    <div class="btn-group">
                                        <button class="btn  btn-danger fa fa-repeat" data-method="rotate" data-option="90" type="button" title="Rotate 90 degrees"> 向右旋转</button>
                                    </div>
                                </div>
                                <div class="col-md-5" style="text-align: right;">
                                    <button class="btn btn-danger fa fa-arrows" data-method="setDragMode" data-option="move" type="button" title="移动">
							            <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="$().cropper(&quot;setDragMode&quot;, &quot;move&quot;)">
							            </span>
							          </button>
                                    <button type="button" class="btn btn-danger fa fa-search-plus" data-method="zoom" data-option="0.1" title="放大图片">
							            <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="$().cropper(&quot;zoom&quot;, 0.1)">
							              <!--<span class="fa fa-search-plus"></span>-->
							            </span>
							          </button>
                                    <button type="button" class="btn btn-danger fa fa-search-minus" data-method="zoom" data-option="-0.1" title="缩小图片">
							            <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="$().cropper(&quot;zoom&quot;, -0.1)">
							              <!--<span class="fa fa-search-minus"></span>-->
							            </span>
							          </button>
                                    <button type="button" class="btn btn-danger fa fa-refresh" data-method="reset" title="重置图片">
								            <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="$().cropper(&quot;reset&quot;)" aria-describedby="tooltip866214">
								       </button>
                                </div>
                                <div class="col-md-3">
                                    <button class="btn btn-danger btn-block avatar-save fa fa-save" type="button" data-dismiss="modal"> 保存修改</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--头像上传model  end-->
</div>
<!--底部开始 -->
<footer class="footer-small">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="copyright">
                    <p>&copy; Copyright - @2017 宜宾辉越科技有限公司<br><a target="_blank" href="http://www.miitbeian.gov.cn/">蜀ICP备17021191号</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--底部结束-->

<!-- js placed at the end of the document so the pages load faster -->
<!-- <script src="<?php echo THEME_PATH; ?>xtq/js/jquery-1.8.3.min.js"></script> -->
<!-- <script src="<?php echo THEME_PATH; ?>xtq/js/bootstrap.min.js"></script> -->
<script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/hover-dropdown.js"></script>
<script defer src="<?php echo THEME_PATH; ?>xtq/js/jquery.flexslider.js"></script>
<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.js"></script>

<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/jquery.parallax-1.1.3.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/wow.min.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.carousel.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/mixitup.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/jquery.easing.min.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/link-hover.js"></script>


<!--common script for all pages-->
<script src="<?php echo THEME_PATH; ?>xtq/js/common-scripts.js"></script>
<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/wow.min.js"></script>


<script src="<?php echo THEME_PATH; ?>xtq/js/jquery.magnific-popup.js"></script>

<script src="<?php echo THEME_PATH; ?>xtq/js/jquery.validate.min.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/validate.messages_zh.js"></script>

<script src="<?php echo THEME_PATH; ?>xtq/js/cropper.min.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/sitelogo.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/html2canvas.min.js" type="text/javascript" charset="utf-8"></script>
<script>
    new WOW().init();
    $().ready(function() {
        $("#shimin").validate();
        $("#email-bd").validate();
        $("#mobile-bd").validate();
        $("#password-edit").validate();
    });
    // 编辑用户信息model的信息传递 uid
    $('#editUserModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget) // 触发模态的按钮
            var recipient = button.data('uid') // 从data-*属性提取信息
                // 如果有必要，可以在这里启动Ajax请求（然后在回调中进行更新）。
                // 更新模态内容。我们将在这里使用jQuery，但您可以使用数据绑定库或其他方法。
            var modal = $(this)
            modal.find('.modal-body input').val(recipient)
        })
        // 头像上传
        //做个下简易的验证  大小 格式 
    $('#avatarInput').on('change', function(e) {
        var filemaxsize = 1024 * 5; //5M
        var target = $(e.target);
        var Size = target[0].files[0].size / 1024;
        if (Size > filemaxsize) {
            alert('图片过大，请重新选择!');
            $(".avatar-wrapper").childre().remove;
            return false;
        }
        if (!this.files[0].type.match(/image.*/)) {
            alert('请选择正确的图片!')
        } else {
            var filename = document.querySelector("#avatar-name");
            var texts = document.querySelector("#avatarInput").value;
            var teststr = texts; //你这里的路径写错了
            testend = teststr.match(/[^\\]+\.[^\(]+/i); //直接完整文件名的
            filename.innerHTML = testend;
        }

    });

    $(".avatar-save").on("click", function() {
        var img_lg = document.getElementById('imageHead');
        // 截图小的显示框内的内容
        html2canvas(img_lg, {
            allowTaint: true,
            taintTest: false,
            onrendered: function(canvas) {
                canvas.id = "mycanvas";
                //生成base64图片数据
                var dataUrl = canvas.toDataURL("image/jpeg");
                var newImg = document.createElement("img");
                newImg.src = dataUrl;
                imagesAjax(dataUrl)
            }
        });
    })

    function imagesAjax(src) {
        var data = {};
        data.img = src;
        data.jid = $('#jid').val();
        $.ajax({
            url: "upload-logo.php",
            data: data,
            type: "POST",
            dataType: 'json',
            success: function(re) {
                if (re.status == '1') {
                    $('.user_pic img').attr('src', src);
                }
            }
        });
    }
</script>

</body>

</html>
<?php if ($fn_include = $this->_include("header.html")) include($fn_include); ?>
    <!-- <link rel="shortcut icon" href="img/favicon.png"> -->

    <!--external css-->
    <link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/css/flexslider.css" />
    <link href="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.carousel.css">
    <link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.theme.css">

    </script>

    <link rel="stylesheet" type="text/css" href="<?php echo THEME_PATH; ?>xtq/css/parallax-slider/parallax-slider.css" />

    <script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/parallax-slider/modernizr.custom.28468.js">

    </script>

    <!--面包屑导航开始-->

    <div class="breadcrumbs">

        <div class="container">

            <div class="row">

                <div class="col-lg-4 col-sm-4">

                    <h1>社区生活</h1>

                </div>

                <div class="col-lg-8 col-sm-8">

                    <ol class="breadcrumb pull-right">

                        <li><a href="/">首页</a></li>
                        <?php echo dr_catpos($catid, '', true,'<li class="active"><a href="[url]">[name]</a></li>'); ?>

                    </ol>

                </div>

            </div>

        </div>

    </div>

    <!--面包屑导航结束-->



    <!--container start-->

    <div class="my_con">

        <div class="login-bg">

            <div class="container" style="padding:20px 0 100px 0;">

                <div class="row">

                    <div class="col-md-9">



                        <div class="topics panel panel-default">



                            <div class="panel-body item-list">
                                <?php $rt = $this->list_tag("action=module catid=31 order=displayorder,updatetime page=1"); if ($rt) extract($rt); $count=count($return); if (is_array($return)) { foreach ($return as $key=>$t) { ?>
                                
                                <div class="topic media">

                                    <div class="avatar media-left">

                                        <a href="<?php echo $t['url']; ?>"><img class="media-object avatar-48" src="<?php echo dr_get_file($cat['thumb']); ?>"></a>

                                    </div>

                                    <div class="infos media-body">

                                        <div class="title media-heading">

                                            <a title="<?php echo $t['title']; ?>" href="<?php echo $t['url']; ?>">

                                                <?php echo $t['title']; ?>

                                            </a> <i class="fa fa-thumb-tack" title="置顶"></i>

                                        </div>

                                        <div class="info">

                                            <a class="user-name" href="#"><?php echo $t['author']; ?></a>

                                            <span class="hidden-mobile"> • 最后由 
                                            <a class="user-name" href="<?php echo $t['url']; ?>"><?php echo $t['author']; ?></a>
                                             回复于 
                                             <abbr class="timeago" title=""><?php echo $t['updatetime']; ?></abbr>
                                             </span>

                                        </div>

                                    </div>

                                    <div class="count media-right">

                                        <a class="state-false" href="<?php echo $t['url']; ?>"><?php if ($t['vire'] == '') { ?>0<?php } else {  echo $t['view'];  } ?></a>

                                    </div>

                                </div>
                                <?php } } ?>

                                

                            </div>



                            <div class="panel-footer clearfix">

                                <ul class="pagination">

                                  <?php echo $pages; ?>

                                </ul>



                            </div>

                        </div>



                    </div>





                    <div class="sidebar col-md-3">

                        <div class="panel panel-default">

                            <div class="panel-body">

                                <a class="btn btn-success btn-block" href="#">发布新话题</a>

                            </div>

                        </div>



                        <div class="panel panel-default">

                            <div class="panel-heading">小帖士</div>

                            <div class="panel-body">
                                    <?php echo dr_block(8); ?>

                            </div>

                        </div>



                    </div>



                </div>

            </div>

        </div>

    </div>

    <!--container end-->


<?php if ($fn_include = $this->_include("footer.html")) include($fn_include); ?>

    <!-- js placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/hover-dropdown.js"></script>
    <script defer src="<?php echo THEME_PATH; ?>xtq/js/jquery.flexslider.js"></script>
    <script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.js"></script>

    <script src="<?php echo THEME_PATH; ?>xtq/js/jquery.easing.min.js"></script>
    <script src="<?php echo THEME_PATH; ?>xtq/js/link-hover.js"></script>
    <script src="<?php echo THEME_PATH; ?>xtq/js/jquery.validate.min.js"></script>
    <script src="<?php echo THEME_PATH; ?>xtq/js/validate.messages_zh.js"></script>

    <script>

        wow = new WOW({

            boxClass: 'wow', // default

            animateClass: 'animated', // default

            offset: 0 // default

        })

        wow.init();

    </script>

</body>



</html>
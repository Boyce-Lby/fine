<?php if ($fn_include = $this->_include("header.html")) include($fn_include); ?>

<!--external css-->
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/css/flexslider.css" />
<link href="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.theme.css">




<!--面包屑导航开始-->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-4">
                <h1>关于我们</h1>
            </div>
            <div class="col-lg-8 col-sm-8">
                <ol class="breadcrumb pull-right">
                    <li><a href="index.html">首页</a></li>
                    <li class="active"><?php echo dr_catpos($catid, '', true, '[name]'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!--面包屑导航结束-->

<!--container start-->
<div class="my_con">
    <div class="container">

        <div class="row mar-b-15">
            <div class="col-sm-12">
                <div class="tabs-container">
                    <ul class="nav nav-tabs nav-justified">
                        <li class="active"><a data-toggle="tab" href="#tab-1" aria-expanded="true">公司简介</a>
                        </li>
                        <li class=""><a data-toggle="tab" href="#tab-2" aria-expanded="false">品牌文化</a>
                        </li>
                        </li>
                        <!--  <li class=""><a data-toggle="tab" href="#tab-3" aria-expanded="false">发展历程</a>
                            </li> -->
                        </li>
                        <li class=""><a data-toggle="tab" href="#tab-4" aria-expanded="false">新闻活动</a>
                        </li>
                        <li class=""><a data-toggle="tab" href="#tab-5" aria-expanded="false">合伙人</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="tab-1" class="tab-pane active">
                            <div class="panel-body">
                                <?php echo dr_block(4); ?>
                            </div>
                        </div>
                        <div id="tab-2" class="tab-pane">
                            <div class="panel-body">
                                <?php echo dr_block(5); ?>
                            </div>
                        </div>
                        <!--  <div id="tab-3" class="tab-pane">
                                <div class="panel-body">
                                    <?php echo dr_block(6); ?>
                                </div>
                            </div> -->
                        <div id="tab-4" class="tab-pane">
                            <div class="panel-body">
                                <?php $rt = $this->list_tag("action=module catid=30 order=displayorder,updatetime page=1"); if ($rt) extract($rt); $count=count($return); if (is_array($return)) { foreach ($return as $key=>$t) { ?>
                                <div class="media">
                                    <div class="pull-left">
                                        <span class="time"><?php echo $t['updatetime']; ?></span>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading"><a href="<?php echo $t['url']; ?>"><?php echo $t['title']; ?></a></h4>
                                        <?php echo $t['description']; ?>
                                    </div>
                                </div>
                                <?php } } ?>
                                <div class="pages">
                                    <ul class="pagination">
                                        <?php echo $pages; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div id="tab-5" class="tab-pane">
                            <div class="panel-body">
                                <!-- career -->
                                <div class="row">
                                    <?php echo dr_block(7); ?>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <?php $rt = $this->list_tag("action=module catid=29 order=displayorder,updatetime page=1"); if ($rt) extract($rt); $count=count($return); if (is_array($return)) { foreach ($return as $key=>$t) { ?>
                                        <div class="candidate wow fadeInLeft">

                                            <div class="media">
                                                <div class="pull-left">
                                                    <a href="#">
                                                        <img class="media-object patner" src="<?php echo dr_get_file($t['thumb']); ?>">
                                                    </a>
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading"><?php echo $t['title']; ?></h4>
                                                    <?php echo $t['description']; ?>
                                                </div>
                                            </div>

                                        </div>
                                        <hr> <?php } } ?>
                                        <div class="candidate wow fadeInRight">
                                            <div class="media">
                                                <div class="pull-left">
                                                    <a href="#">
                                                        <img class="media-object patner" src="images/product1.jpg">
                                                    </a>
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">合伙人</h4>
                                                    简介内容简介内容简介内容简介内容简介内容简介内容简介内容简介内容简介内容简介内容简介内容
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                    </div>
                                    <!-- career -->
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>






    <!--container end-->

    <?php if ($fn_include = $this->_include("footer.html")) include($fn_include); ?>

    <!-- js placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/hover-dropdown.js"></script>
    <script defer src="<?php echo THEME_PATH; ?>xtq/js/jquery.flexslider.js"></script>
    <script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.js"></script>

    <script src="<?php echo THEME_PATH; ?>xtq/js/jquery.easing.min.js"></script>
    <script src="<?php echo THEME_PATH; ?>xtq/js/link-hover.js"></script>
    <script src="<?php echo THEME_PATH; ?>xtq/js/jquery.validate.min.js"></script>
    <script src="<?php echo THEME_PATH; ?>xtq/js/validate.messages_zh.js"></script>




    <script>
        wow = new WOW({
            boxClass: 'wow', // default
            animateClass: 'animated', // default
            offset: 0 // default
        })
        wow.init();
    </script>

    </body>

    </html>
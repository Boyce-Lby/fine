<?php if ($fn_include = $this->_include("header.html")) include($fn_include); ?>
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/css/flexslider.css" />
<link href="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.theme.css">
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/css/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="<?php echo THEME_PATH; ?>xtq/css/mixitup.css">


<!--面包屑导航开始-->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-4">
                <h1>农家小店</h1>
            </div>
            <div class="col-lg-8 col-sm-8">
                <ol class="breadcrumb pull-right">
                    <li><a href="index.html">首页</a></li>
                    <li class="active"><?php echo dr_catpos($catid, '', true, '<a href="[url]">[name]</a>'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!--面包屑导航结束-->
<div class="my_con">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="pf-img">
                    <img src="<?php echo dr_get_file($thumb); ?>" alt="" height="500">
                </div>

            </div>
        </div>
    </div>

    <!--container start-->
    <div class="container">
        <div class="row">
            <!--portfolio-single start-->

            <div class="col-lg-9 ">
                <div class="title">
                    <h3><?php echo $title; ?></h3>
                    <hr>
                </div>
                <div class="pf-detail">
                    <p>
                        <?php echo $description; ?>
                    </p>
                </div>
                <!-- <p><button class="btn bg-maroon margin"><i class="fa fa-external-link pr-5"></i>Preview</button></p> -->
            </div>

            <div class="col-lg-3">
                <div class="title">
                    <h3>店铺信息</h3>
                    <hr>
                </div>
                <ul class="list-unstyled pf-list">
                    <li><i class="fa fa-arrow-circle-right pr-10"></i><b>店主: </b> <span><a href="#"><?php echo $dianzhu; ?></a></span></li>
                    <li><i class="fa fa-arrow-circle-right pr-10"></i><b>物流评分: </b><span>4.4</span></li>
                    <li><i class="fa fa-arrow-circle-right pr-10"></i><b>描述: </b><span>5</span></li>
                    <li><i class="fa fa-arrow-circle-right pr-10"></i><b>服务: </b><span>5</span></li>
                    <li><i class="fa fa-arrow-circle-right pr-10"></i><b>访问量: </b><span><?php echo $fangwenliang; ?></span></li>
                </ul>
            </div>
        </div>
        <hr>
    </div>
    <!--筛选  开始-->
    <div class="container">

        <div class="row">
            <div class="col-md-6">
                <ul id="filters" class="clearfix">
                    <li><span class="filter active" data-filter="app card icon logo web">全部</span></li>
                    <li><span class="filter" data-filter="app">热卖</span></li>
                    <li><span class="filter" data-filter="card">新品</span></li>
                    <li><span class="filter" data-filter="icon">推荐</span></li>
                    <li><span class="filter" data-filter="logo">精品</span></li>
                </ul>
            </div>
        </div>
    </div>
    <!--筛选  结束-->
    <!--图片列表  开始-->
    <div class="container">
        <div class="row mar-b-30">
            <div id="portfoliolist-three">
                <div class="col-md-12">
                    <div class="portfolio logo" data-cat="logo">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">

                                    <ul class="list-unstyled price-type">
                                        <li>美的电冰箱</li>
                                        <li>价格：￥13133</li>
                                        <li><a href="#" class="btn btn-success">查看详情</a></li>
                                    </ul>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" alt="" />

                            </div>
                        </div>
                    </div>

                    <div class="portfolio app" data-cat="app">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">

                                    <ul class="list-unstyled price-type">
                                        <li>美的电冰箱</li>
                                        <li>价格：￥13133</li>
                                        <li><a href="#" class="btn btn-success">查看详情</a></li>
                                    </ul>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/app/3.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio web" data-cat="web">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">

                                    <ul class="list-unstyled price-type">
                                        <li>美的电冰箱</li>
                                        <li>价格：￥13133</li>
                                        <li><a href="#" class="btn btn-success">查看详情</a></li>
                                    </ul>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/web/1.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio card" data-cat="card">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">

                                    <ul class="list-unstyled price-type">
                                        <li>美的电冰箱</li>
                                        <li>价格：￥13133</li>
                                        <li><a href="#" class="btn btn-success">查看详情</a></li>
                                    </ul>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/card/1.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio app" data-cat="app">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">

                                    <ul class="list-unstyled price-type">
                                        <li>美的电冰箱</li>
                                        <li>价格：￥13133</li>
                                        <li><a href="#" class="btn btn-success">查看详情</a></li>
                                    </ul>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/app/3.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio card" data-cat="card">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/card/1.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/card/1.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio card" data-cat="card">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/card/4.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/card/4.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio logo" data-cat="logo">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio app" data-cat="app">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/app/1.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/app/1.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio card" data-cat="card">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/card/2.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/card/2.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio logo" data-cat="logo">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio logo" data-cat="logo">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio icon" data-cat="icon">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/icon/3.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/icon/3.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio web" data-cat="web">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/web/1.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/web/1.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio icon" data-cat="icon">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/icon/1.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/icon/1.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio web" data-cat="web">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/web/2.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/web/2.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio icon" data-cat="icon">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/icon/3.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/icon/3.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio icon" data-cat="icon">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/icon/5.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/icon/5.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio web" data-cat="web">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/web/4.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/web/4.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio logo" data-cat="logo">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/2.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/2.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio logo" data-cat="logo">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/3.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/3.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio icon" data-cat="icon">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio card" data-cat="card">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/card/4.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/card/4.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div class="portfolio logo" data-cat="logo">
                        <div class="portfolio-wrapper">
                            <div class="portfolio-hover">
                                <div class="image-caption">
                                    <a href="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" class="label magnefig label-info icon" data-toggle="tooltip" data-placement="left" title="Zoom"><i class="fa fa-eye"></i></a>
                                    <a href="blog-detail.html" class="label label-info icon" data-toggle="tooltip" data-placement="top" title="Details"><i class="fa fa-link"></i></a>
                                    <a href="#" class="label label-info icon" data-toggle="tooltip" data-placement="right" title="Likes"><i class="fa fa-heart"></i></a>

                                </div>
                                <img src="<?php echo THEME_PATH; ?>xtq/img/portfolios/logo/5.jpg" alt="" />
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!--图片列表  结束-->

</div>
<?php if ($fn_include = $this->_include("footer.html")) include($fn_include); ?>
<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/hover-dropdown.js"></script>
<script defer src="<?php echo THEME_PATH; ?>xtq/js/jquery.flexslider.js"></script>
<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.js"></script>

<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/jquery.parallax-1.1.3.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.carousel.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/mixitup.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/jquery.easing.min.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/link-hover.js"></script>

<script src="<?php echo THEME_PATH; ?>xtq/js/jquery.magnific-popup.js"></script>
<script>
    new WOW().init();
    $('.image-caption a').tooltip();

    $(function() {

        var filterList = {

            init: function() {

                // MixItUp plugin
                // http://mixitup.io
                $('#portfoliolist-three').mixitup({
                    targetSelector: '.portfolio',
                    filterSelector: '.filter',
                    effects: ['fade'],
                    easing: 'snap',
                    // call the hover effect
                    onMixEnd: filterList.hoverEffect()
                });

            },

            hoverEffect: function() {
                $("[rel='tooltip']").tooltip();
                // Simple parallax effect
                $('#portfoliolist-three .portfolio .portfolio-hover').hover(
                    function() {
                        $(this).find('.image-caption').slideDown(250); //.fadeIn(250)
                    },
                    function() {
                        $(this).find('.image-caption').slideUp(250); //.fadeOut(205)
                    }
                );
            }

        };

        // Run the show!
        filterList.init();


    });
</script>

</body>

</html>
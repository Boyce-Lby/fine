<?php if ($fn_include = $this->_include("header.html")) include($fn_include); ?>
<!-- <link rel="shortcut icon" href="<?php echo THEME_PATH; ?>xtq/img/favicon.png"> -->

<!--external css-->
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/css/flexslider.css" />
<link href="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo THEME_PATH; ?>xtq/assets/owlcarousel/owl.theme.css">

</script>

<!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
<!--[if lt IE 9]>
    <script src="js/html5shiv.js">
    </script>
    <script src="js/respond.min.js">
    </script>
    <![endif]-->

<!--面包屑导航开始-->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-4">
                <h1>阳光政务</h1>
            </div>
            <div class="col-lg-8 col-sm-8">
                <ol class="breadcrumb pull-right">
                    <li><a href="/">首页</a></li>
                    <li class="active"><?php echo dr_catpos($catid, '', true,'<a href="[url]">[name]</a>'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!--面包屑导航结束-->

<!--container start-->
<div class="my_con">
    <div class="container">
        <div class="row mar-b-50">
            <div class="col-lg-5">
                <div class="about-carousel wow fadeInLeft">
                    <div id="myCarousel" class="carousel slide">
                        <!-- Carousel items -->
                        <div class="carousel-inner">
                            <div class="active item">
                                <img src="<?php echo THEME_PATH; ?>xtq/img/yb1.jpg" alt="">
                                <div class="carousel-caption">
                                    <p>
                                        宜宾夜景
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <img src="<?php echo THEME_PATH; ?>xtq/img/yb2.jpg" alt="">
                                <div class="carousel-caption">
                                    <p>
                                        五粮液
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <img src="<?php echo THEME_PATH; ?>xtq/img/yb3.jpg" alt="">
                                <div class="carousel-caption">
                                    <p>
                                        五粮液雕塑
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <img src="<?php echo THEME_PATH; ?>xtq/img/yb4.jpg" alt="">
                                <div class="carousel-caption">
                                    <p>
                                        蜀南竹海
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <img src="<?php echo THEME_PATH; ?>xtq/img/yb5.jpg" alt="">
                                <div class="carousel-caption">
                                    <p>
                                        兴文石林
                                    </p>
                                </div>
                            </div>

                        </div>
                        <!-- Carousel nav -->
                        <a class="carousel-control left" href="#myCarousel" data-slide="prev">
                            <i class="fa fa-angle-left">
                </i>
                        </a>
                        <a class="carousel-control right" href="#myCarousel" data-slide="next">
                            <i class="fa fa-angle-right">
                </i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 about wow fadeInRight">
                <h3>
                    <b>宜宾</b> （四川省省辖市）
                </h3>
                <p>
                    宜宾，四川省地级市，国家历史文化名城，以五粮液为代表的发达的酿酒工业使宜宾成为名副其实的“中国酒都”。[1-2] 宜宾是长江上游开发最早、历史最悠久的城市之一，是南丝绸之路的起点，素有“西南半壁古戎州”的美誉，古称“僰道”、“戎州”、“叙州”，位于四川省南部，川、滇、黔三省结合部，长江零公里处。辖二区八县（翠屏区、南溪区、宜宾县、江安县、长宁县、高县、筠连县、珙县、兴文县、屏山县）。 宜宾战略位置重要，是成都经济区、川南经济区、攀西经济区的融合点，辐射周边人口多达2000余万，是毗邻地区的中心城市。
                    宜宾的能源（水电、火电、煤炭、页岩气等）丰富、产业发达，提供就业岗位众多，交通方面高速公路网络、高铁网络、长江港口、民用机场一应俱全。[3] 2017年6月，宜宾市被命名国家卫生城市。
                </p>
            </div>
        </div>

    </div>
    <div class="container">

        <div class="row mar-b-15">
            <div class="col-sm-12">
                <div class="tabs-container">
                    <ul class="nav nav-tabs nav-justified">
                        <?php if (is_array($related)) { $count=count($related);foreach ($related as $c) { ?>

                        <li class="<?php if ($c['name'] == '最新公告') { ?>active<?php } ?>">
                            <a data-toggle="tab" href="#tab-<?php echo $c['id']; ?>" aria-expanded="false"><?php echo $c['name']; ?></a> <?php } } ?>


                    </ul>
                    <div class="tab-content">
                        <?php if (is_array($related)) { $count=count($related);foreach ($related as $c) { ?>
                        <div id="tab-<?php echo $c['id']; ?>" class="tab-pane <?php if ($c['name'] == '最新公告') { ?>active<?php } ?>">
                            <div class="panel-body">
                                <?php $rt = $this->list_tag("action=module catid=$c[id] order=displayorder,updatetime page=1"); if ($rt) extract($rt); $count=count($return); if (is_array($return)) { foreach ($return as $key=>$t) { ?>
                                <div class="media">
                                    <div class="media-left">
                                        <img src="<?php if ($t['thumb']) {  echo dr_get_file($t['thumb']);  } else {  echo THEME_PATH; ?>xtq/img/yb4.jpg<?php } ?>" border="0" width="200">
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading"><a href="<?php echo $t['url']; ?>"><?php echo $t['title']; ?></a></h4>
                                        <p><?php echo $t['description']; ?></p>
                                        <span class="time pull-right"><?php echo $t['updatetime']; ?></span>
                                    </div>

                                </div>
                                <hr> <?php } } ?>
                                <div class="pages">
                                    <ul class="pagination">
                                        <?php echo $pages; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <?php } } ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>






<!--container end-->

<?php if ($fn_include = $this->_include("footer.html")) include($fn_include); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/js/hover-dropdown.js"></script>
<script defer src="<?php echo THEME_PATH; ?>xtq/js/jquery.flexslider.js"></script>
<script type="text/javascript" src="<?php echo THEME_PATH; ?>xtq/assets/bxslider/jquery.bxslider.js"></script>

<script src="<?php echo THEME_PATH; ?>xtq/js/jquery.easing.min.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/link-hover.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/jquery.validate.min.js"></script>
<script src="<?php echo THEME_PATH; ?>xtq/js/validate.messages_zh.js"></script>

<script>
    wow = new WOW({
        boxClass: 'wow', // default
        animateClass: 'animated', // default
        offset: 0 // default
    })
    wow.init();
</script>

</body>

</html>
    <!--底部开始 -->
    <footer class="footer-small">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <div class="copyright">
                        <p style="font-size:12px;text-align:center;">&copy; Copyright - @2017 宜宾辉越科技有限公司<br><a target="_blank" href="http://www.miitbeian.gov.cn/">蜀ICP备17021191号</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--底部结束-->

    <script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo THEME_PATH; ?>js/<?php echo SITE_LANGUAGE; ?>.js"></script>
		<script src="<?php echo THEME_PATH; ?>xtq/js/wow.min.js"></script>
		<script src="<?php echo THEME_PATH; ?>xtq/js/common-scripts.js"></script>
